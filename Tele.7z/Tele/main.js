const TelegramBot = require('node-telegram-bot-api');
const { getBotStatus } = require('./botstatus');
const fs = require('fs');
const token = '6749131061:AAFilJzHDrySr4JIXhxIAz-xQwhrg2syWV0'
const bot = new TelegramBot(token, { polling: true })
bot.commands = new Map()
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'))
for (const file of commandFiles) {
  const command = require(`./commands/${file}`)
  bot.commands.set(command.name, command)
}
bot.on('message', (msg) => {
  if (!msg.text.startsWith('/')) return
  const args = msg.text.slice(1).split(' ')
  const commandName = args.shift().toLowerCase()
  if (!bot.commands.has(commandName)) return;
  const command = bot.commands.get(commandName)
  try {
    command.execute(bot, msg, args)
  } catch (error) {
    console.error(error)
    bot.sendMessage(msg.chat.id, 'Lỗi con mẹ nó rồi')
  }
})