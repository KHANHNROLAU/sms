let isBotActive = true;

const setBotStatus = (status) => {
  isBotActive = status;
};

const getBotStatus = () => isBotActive;

module.exports = { setBotStatus, getBotStatus };