module.exports = {
  name: 'start',
  description: 'Lệnh bắt đầu',
  execute(bot, message) {
    bot.sendMessage(message.chat.id, 'Danh sách lệnh:/help');
  },
};