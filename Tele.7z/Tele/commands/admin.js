module.exports = {
  name: 'admin',
  description: 'Hiển thị thông tin admin',
  execute(bot, message) {
    // Thay thế 'YOUR_TELEGRAM_ADMIN_ID' bằng ID Telegram của admin
    const adminId = '@inolove_v';
    bot.sendMessage(message.chat.id, `Admin: ${adminId}`);
  },
};