const fs = require('fs');

module.exports = {
  name: 'taixiu',
  description: 'Chơi game Tài Xỉu',
  execute(bot, message, args) {
    const choice = args[0]; // 't' hoặc 'x'
    const betAmount = parseInt(args[1], 10);
    const userId = message.from.id.toString(); // Lấy UID từ thông tin người gửi
    const userName = message.from.username; // Lấy tên người dùng

    if (!choice || isNaN(betAmount)) {
      return bot.sendMessage(message.chat.id, 'Cú pháp không đúng. Vui lòng nhập /taixiu [t/x] [Số Tiền].');
    }

    // Đọc file account.json
    fs.readFile('account.json', 'utf8', (err, data) => {
      if (err) {
        console.log('Error reading file:', err);
        return bot.sendMessage(message.chat.id, 'Lỗi khi đọc file dữ liệu.');
      }
      try {
        const accounts = JSON.parse(data);
        // Kiểm tra xem UID có tồn tại trong file không
        const userAccount = accounts[userId];
        if (userAccount && userAccount.Balance >= betAmount) {
          // Trừ tiền cược từ tài khoản
          userAccount.Balance -= betAmount;
          // Sinh số ngẫu nhiên từ 1 đến 100
          const randomNumber = Math.floor(Math.random() * 100) + 1;
          let result;
          let gameResult;
          if (randomNumber < 50) {
            result = 't';
            gameResult = 'Tài';
          } else {
            result = 'x';
            gameResult = 'Xỉu';
          }
          // Kiểm tra kết quả và cập nhật số dư
          let winLossMessage;
          if (choice === result) {
            userAccount.Balance += betAmount * 2; // Nhân 2 số tiền cược nếu thắng
            winLossMessage = `Tiền thắng: ${(betAmount * 2).toLocaleString('vi-VN')} VND`;
          } else {
            winLossMessage = `Tiền thua: ${betAmount.toLocaleString('vi-VN')} VND`;
          }
          // Lấy thời gian hiện tại
          const currentTime = new Date().toLocaleString('vi-VN');
          // Ghi lại dữ liệu vào file
          fs.writeFile('account.json', JSON.stringify(accounts, null, 2), (writeErr) => {
            if (writeErr) {
              console.log('Error writing file:', writeErr);
              return bot.sendMessage(message.chat.id, 'Lỗi khi cập nhật dữ liệu.');
            }
            // Gửi thông báo kết quả với hiệu ứng dice
            const diceEmoji = '🎲';
            const diceAnimation = Array.from({ length: 6 }, (_, i) => `${diceEmoji}${i + 1}`).join(' ');
            const resultMessage = `┏━━━━━━━━━━━━━┓\n┣➤Kết quả: ${gameResult} ${diceAnimation}\n┣➤Tên người đặt cược: ${userName}\n┣➤Số tiền đặt cược: ${betAmount.toLocaleString('vi-VN')} VND\n┣➤${winLossMessage}\n┣➤Thời gian đặt cược: ${currentTime}\n┗━━━━━━━━━━━━━┛`;
            bot.sendMessage(message.chat.id, resultMessage);
          });
        } else {
          bot.sendMessage(message.chat.id, 'Không đủ số dư hoặc không tìm thấy thông tin người dùng.');
        }
      } catch (parseErr) {
        console.log('Error parsing JSON:', parseErr);
        bot.sendMessage(message.chat.id, 'Lỗi khi phân tích cú pháp dữ liệu.');
      }
    });

    // Đặt thời gian chờ cho lần chơi tiếp theo
    setTimeout(() => {
      bot.sendMessage(message.chat.id, 'Bạn có thể đặt cược lại.');
    }, 5000); // Delay 5 giây
  },
};
