const gtts = require('node-gtts')('vi'); // 'vi' là mã ngôn ngữ cho tiếng Việt
const fs = require('fs');

module.exports = {
  name: 'cdvb',
  description: 'Chuyển đổi văn bản thành giọng nói',
  execute(bot, message, args) {
    // Nối các đối số để tạo ra văn bản cần chuyển đổi
    const text = args.join(' ');
    if (!text) {
      return bot.sendMessage(message.chat.id, 'Vui lòng nhập văn bản để chuyển đổi.');
    }
    // Tạo một file âm thanh từ văn bản
    const speech = gtts.stream(text);
    const filename = `speech-${Date.now()}.mp3`;
    const writeStream = fs.createWriteStream(filename);
    speech.pipe(writeStream);

    writeStream.on('finish', () => {
      // Gửi file âm thanh khi nó đã sẵn sàng
      bot.sendAudio(message.chat.id, filename, { caption: 'This voice' })
        .then(() => {
          // Xóa file sau khi gửi để không chiếm dụng bộ nhớ
          fs.unlinkSync(filename);
        })
        .catch(err => {
          console.error('Error sending audio:', err);
          bot.sendMessage(message.chat.id, 'Lỗi khi gửi file âm thanh.');
        });
    });

    writeStream.on('error', (err) => {
      console.error('Error writing audio file:', err);
      bot.sendMessage(message.chat.id, 'Lỗi khi tạo file âm thanh.');
    });
  },
};