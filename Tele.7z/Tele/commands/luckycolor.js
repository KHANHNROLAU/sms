const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'luckycolor',
  description: 'Chơi game phi tiêu',
  execute(bot, message, args) {
    const accountsPath = path.join(__dirname, '../account.json');
    const choice = args[0]; // 't' hoặc 'd'
    const betAmount = parseInt(args[1], 10);
    const minBetAmount = 50000000; // Số tiền cược tối thiểu là 50 triệu

    if (!choice || isNaN(betAmount)) {
      return bot.sendMessage(message.chat.id, 'Cú pháp không đúng. Vui lòng nhập /luckycolor [t/d] [Số Tiền].');
    }

    if (betAmount < minBetAmount) {
      return bot.sendMessage(message.chat.id, `Số tiền cược không được thấp hơn ${minBetAmount.toLocaleString('vi-VN')} VND.`);
    }

    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const userId = message.from.id.toString();
      const userAccount = accounts[userId];

      if (!userAccount) {
        return bot.sendMessage(message.chat.id, 'Tài khoản của bạn không tồn tại.');
      }

      if (userAccount.Balance < betAmount) {
        return bot.sendMessage(message.chat.id, 'Số dư tài khoản của bạn không đủ để thực hiện giao dịch này.');
      }

      // Sinh kết quả ngẫu nhiên và gửi emoji tương ứng
      const result = Math.random() < 0.5 ? 't' : 'd';
      const emoji = result === 't' ? '⚪' : '🔴';

      bot.sendMessage(message.chat.id, emoji);

      // Kiểm tra kết quả và cập nhật số dư
      if (choice === result) {
        userAccount.Balance += betAmount; // Nhân 2 số tiền cược nếu thắng
        bot.sendMessage(message.chat.id, `┏━━━━━━━━━━━━━┓\n┣➤Bạn chọn: ${choice.toUpperCase()}\n┣➤Số dư tài khoản hiện này: ${userAccount.Balance.toLocaleString('vi-VN')} VND\n┣➤Status:Thắng\n┗━━━━━━━━━━━━━┛`);
      } else {
        userAccount.Balance -= betAmount;
        bot.sendMessage(message.chat.id, `┏━━━━━━━━━━━━━┓\n┣➤Bạn chọn: ${choice.toUpperCase()}\n┣➤Số dư tài khoản hiện này: ${userAccount.Balance.toLocaleString('vi-VN')} VND\n┣➤Status:Thua\n┗━━━━━━━━━━━━━┛`);
      }

      // Ghi lại thông tin vào file account.json
      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
        }
      });
    });
  },
};