const fs = require('fs');
const path = require('path');

// Thay thế với ID thực của admin
const ADMIN_USER_ID = '5990807551';

module.exports = {
  name: 'rmacc',
  description: 'Xóa tài khoản (chỉ dành cho admin)',
  execute(bot, message, args) {
    // Kiểm tra xem người gửi lệnh có phải là admin không
    if (message.from.id.toString() !== ADMIN_USER_ID) {
      return bot.sendMessage(message.chat.id, 'Bạn không có quyền thực hiện hành động này.');
    }

    const accountsPath = path.join(__dirname, '../account.json');
    const usernameToRemove = args && args.length > 0 ? args[0].toLowerCase() : null;

    if (!usernameToRemove) {
      return bot.sendMessage(message.chat.id, 'Vui lòng nhập tên tài khoản cần xóa.');
    }

    // Đọc file account.json
    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      // Kiểm tra xem tài khoản tồn tại không
      if (!accounts[usernameToRemove]) {
        return bot.sendMessage(message.chat.id, 'Tài khoản không tồn tại.');
      }

      // Xóa tài khoản
      delete accounts[usernameToRemove];

      // Ghi lại thông tin vào file account.json
      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật file account.json.');
        }
        bot.sendMessage(message.chat.id, `Tài khoản '${usernameToRemove}' đã được xóa thành công.`);
      });
    });
  },
};
