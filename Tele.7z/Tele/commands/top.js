const fs = require('fs');

module.exports = {
  name: 'top',
  description: 'Hiển thị top 6 người dùng có số dư cao nhất',
  execute(bot, message) {
    // Đọc file account.json
    fs.readFile('account.json', 'utf8', (err, data) => {
      if (err) {
        console.log('Error reading file:', err);
        return bot.sendMessage(message.chat.id, 'Lỗi khi đọc file dữ liệu.');
      }
      try {
        // Phân tích cú pháp dữ liệu JSON
        const accounts = JSON.parse(data);
        // Tạo một mảng từ các giá trị của đối tượng accounts
        const balances = Object.values(accounts);
        // Sắp xếp mảng dựa trên số dư từ cao xuống thấp
        const topBalances = balances.sort((a, b) => b.Balance - a.Balance).slice(0, 6);
        // Tạo một chuỗi để hiển thị thông tin
        let responseText = 'Top 6 người dùng giàu nhất:\n';
        topBalances.forEach((account, index) => {
          responseText += `${index + 1}. ${account.Name}: ${account.Balance.toLocaleString('vi-VN')} VND\n`;
        });
        // Gửi thông tin top 6 người dùng
        bot.sendMessage(message.chat.id, responseText);
      } catch (parseErr) {
        console.log('Error parsing JSON:', parseErr);
        bot.sendMessage(message.chat.id, 'Lỗi khi phân tích cú pháp dữ liệu.');
      }
    });
  },
};