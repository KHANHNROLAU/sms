const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'nangcapets',
  description: 'Nâng cấp thú cưng',
  execute(bot, message) {
    const accountsPath = path.join(__dirname, '../account.json');
    const userId = message.from.id.toString();
    const userPet = message.from.pet;

    // Đọc file account.json
    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const userAccount = accounts[userId];

      if (!userAccount) {
        return bot.sendMessage(message.chat.id, 'Tài khoản của bạn không tồn tại.');
      }

      // Kiểm tra xem đã có thú cưng hay chưa
      if (!userPet) {
        return bot.sendMessage(message.chat.id, 'Bạn chưa có thú cưng.');
      }

      // Xác định giá nâng cấp
      const upgradeCosts = [20e9, 40e9, 80e9, 160e9, 320e9, 640e9, 1280e9, 2560e9, 5120e9];
      const currentLevel = parseInt(userPet.split(' ')[1], 10);
      const nextLevel = currentLevel + 1;

      if (nextLevel > 10) {
        return bot.sendMessage(message.chat.id, 'Thú cưng đã đạt cấp tối đa.');
      }

      const cost = upgradeCosts[nextLevel - 2];
      if (userAccount.Balance < cost) {
        return bot.sendMessage(message.chat.id, 'Số dư của bạn không đủ để nâng cấp thú cưng.\nCấp 1 → Cấp 2: Mất 20 tỷ VND\nCấp 2 → Cấp 3: Mất 40 tỷ VND\nCấp 3 → Cấp 4: Mất 80 tỷ VND\nCấp 4 → Cấp 5: Mất 160 tỷ VND\nCấp 5 → Cấp 6: Mất 320 tỷ VND\nCấp 6 → Cấp 7: Mất 640 tỷ VND\nCấp 7 → Cấp 8: Mất 1,280 tỷ VND\nCấp 8 → Cấp 9: Mất 2,560 tỷ VND\nCấp 9 → Cấp 10: Mất 5,120 tỷ VND');
      }
      userAccount.Balance -= cost;

      // Cập nhật thú cưng
      userAccount.pet = `Cấp ${nextLevel}`;

      // Ghi lại thông tin vào file account.json
      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
        }
        bot.sendMessage(message.chat.id, `Bạn đã nâng cấp thú cưng lên cấp ${nextLevel} thành công! 🐾`);
      });
    });
  },
};
