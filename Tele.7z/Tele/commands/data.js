const axios = require('axios');
const fs = require('fs');

module.exports = {
  name: 'data',
  description: 'Lấy dữ liệu và cookie từ một URL và gửi file chứa thông tin',
  execute(bot, message, args) {
    const url = args[0];
    if (!url) {
      return bot.sendMessage(message.chat.id, 'Vui lòng cung cấp một url');
    }

    // Thực hiện yêu cầu GET tới trang web
    axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
        // Thêm cookie nếu cần
      },
      // Lấy thông tin phản hồi đầy đủ bao gồm header
      responseType: 'arraybuffer'
    })
    .then(response => {
      // Lưu dữ liệu vào một file
      const filename = `data-${Date.now()}.txt`;
      const content = `Dữ liệu:\n${response.data}\n\nCookie:\n${response.headers['set-cookie']}`;
      fs.writeFileSync(filename, content);

      // Gửi file chứa dữ liệu và cookie
      bot.sendDocument(message.chat.id, filename)
        .then(() => {
          // Xóa file sau khi gửi để không chiếm dụng bộ nhớ
          fs.unlinkSync(filename);
        })
        .catch(err => {
          console.error('Error sending document:', err);
          bot.sendMessage(message.chat.id, 'Lỗi khi gửi file.');
        });
    })
    .catch(error => {
      console.error('Lỗi khi lấy dữ liệu:', error);
      bot.sendMessage(message.chat.id, 'Lỗi khi lấy dữ liệu từ trang web.');
    });
  },
};