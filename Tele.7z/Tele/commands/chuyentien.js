const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'chuyentien',
  description: 'Chuyển tiền cho người dùng khác',
  execute(bot, message, args) {
    const accountsPath = path.join(__dirname, '../account.json');
    const recipientName = args[0];
    const amount = parseInt(args[1], 10);
    const minTransferAmount = 5000000; // Số tiền tối thiểu là 5 triệu

    if (!recipientName || isNaN(amount)) {
      return bot.sendMessage(message.chat.id, 'Cú pháp không đúng. Vui lòng nhập /chuyentien [Tên Người Nhận] [Số Tiền].');
    }

    if (amount < minTransferAmount) {
      return bot.sendMessage(message.chat.id, `Số tiền chuyển không được thấp hơn ${minTransferAmount.toLocaleString('vi-VN')} VND.`);
    }

    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const senderId = message.from.id.toString();
      const senderAccount = accounts[senderId];
      const recipientAccount = Object.values(accounts).find(account => account.Name === recipientName);

      if (!senderAccount) {
        return bot.sendMessage(message.chat.id, 'Tài khoản của bạn không tồn tại.');
      }

      if (senderAccount.Balance < amount) {
        return bot.sendMessage(message.chat.id, 'Số dư tài khoản của bạn không đủ để thực hiện giao dịch này.');
      }

      if (!recipientAccount) {
        return bot.sendMessage(message.chat.id, 'Không có người dùng này.');
      }

      // Thực hiện chuyển tiền
      senderAccount.Balance -= amount;
      recipientAccount.Balance += amount;

      // Lấy thời gian hiện tại
      const transferTime = new Date().toLocaleString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' });

      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
        }
        bot.sendMessage(message.chat.id, `┏━━━━━━━━━━━━━┓\n┣➤Số tiền đã chuyển: ${amount.toLocaleString('vi-VN')} VND\n┣➤Người nhận: ${recipientName}\n┣➤Số dư hiện tại: ${senderAccount.Balance.toLocaleString('vi-VN')} VND\n┣➤Thời gian chuyển: ${transferTime}\n┗━━━━━━━━━━━━━┛`);
      });
    });
  },
};
