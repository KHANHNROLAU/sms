const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'allgiftcode',
  description: 'Hiển thị tất cả giftcode',
  execute(bot, message) {
    const giftcodesPath = path.join(__dirname, '../giftcode.json');

    fs.readFile(giftcodesPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file giftcode.json.');
      }

      const giftcodes = JSON.parse(data || '{}');
      let messageText = '┏━━━━━━━━━━━━━┓\n';
      for (const [code, details] of Object.entries(giftcodes)) {
        messageText += `┣➤Giftcode: ${code}\n┣➤Số lần sử dụng còn lại: ${details.uses}\n┣➤Số tiền: ${details.amount.toLocaleString()} VND\n`;
      }
      messageText += '┗━━━━━━━━━━━━━┛';
      bot.sendMessage(message.chat.id, messageText);
    });
  },
};
