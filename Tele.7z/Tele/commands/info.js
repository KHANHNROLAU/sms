const fs = require('fs');

module.exports = {
  name: 'info',
  description: 'Lấy thông tin người dùng dựa trên username',
  execute(bot, message, args) {
    // Kiểm tra xem args[0] có tồn tại không
    if (!args[0]) {
      return bot.sendMessage(message.chat.id, 'Vui lòng cung cấp uid');
    }
    const username = args[0].startsWith('@') ? args[0].substring(1) : args[0]; // Loại bỏ ký tự '@' nếu có

    // Đọc file account.json
    fs.readFile('account.json', 'utf8', (err, data) => {
      if (err) {
        console.log('Error reading file:', err);
        return bot.sendMessage(message.chat.id, 'Lỗi khi đọc file dữ liệu.');
      }
      try {
        const accounts = JSON.parse(data);
        // Tìm kiếm người dùng dựa trên username
        const userAccount = Object.values(accounts).find(account => account.Name === username);
        if (userAccount) {
          const userInfo = `UID: ${userAccount.ID}\nUser: ${userAccount.Name}\nMoney: ${userAccount.Balance.toLocaleString('vi-VN')} VND\nVàng: ${userAccount.Gold || 0}`; // Thêm thông tin Vàng
          bot.sendMessage(message.chat.id, userInfo);
        } else {
          bot.sendMessage(message.chat.id, 'Không tìm thấy thông tin người dùng này.');
        }
      } catch (parseErr) {
        console.log('Error parsing JSON:', parseErr);
        bot.sendMessage(message.chat.id, 'Lỗi khi phân tích cú pháp dữ liệu.');
      }
    });
  },
};
