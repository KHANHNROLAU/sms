const http2 = require('http2');
const { HTTP2_HEADER_PATH, HTTP2_HEADER_METHOD } = http2.constants;

module.exports = {
  name: 'tdsxu',
  description: 'Kiểm tra thông tin tài khoản trên traodoisub.com',
  execute(bot, message, args) {
    const token = args[0];
    if (!token) {
      return bot.sendMessage(message.chat.id, 'Vui lòng nhập token.');
    }

    const client = http2.connect('https://traodoisub.com');
    const path = `/api/?fields=profile&access_token=${token}`;
    const req = client.request({
      [HTTP2_HEADER_PATH]: path,
      [HTTP2_HEADER_METHOD]: 'GET'
    });

    let data = '';
    req.on('data', (chunk) => { data += chunk; });
    req.on('end', () => {
      client.close();
      try {
        const response = JSON.parse(data);
        if (response.success === 200) {
          const userInfo = `User: ${response.data.user}\nXu: ${response.data.xu}\nXu điều: ${response.data.xudie}`;
          bot.sendMessage(message.chat.id, userInfo);
        } else {
          bot.sendMessage(message.chat.id, 'Token không đúng.');
        }
      } catch (error) {
        console.error('Error parsing response:', error);
        bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi phân tích cú pháp dữ liệu.');
      }
    });

    req.end();
  },
};