const os = require('os');

module.exports = {
  name: 'status',
  description: 'Hiển thị trạng thái sử dụng CPU và RAM',
  execute(bot, message) {
    // Tính toán sử dụng RAM
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const usedMemInGB = (usedMem / 1024 / 1024 / 1024).toFixed(2);
    const totalMemInGB = (totalMem / 1024 / 1024 / 1024).toFixed(2);
    const memUsagePercent = ((usedMem / totalMem) * 100).toFixed(2);

    // Tính toán sử dụng CPU
    const cpus = os.cpus();
    const cpuLoad = cpus.map(cpu => {
      const total = Object.values(cpu.times).reduce((acc, tv) => acc + tv, 0);
      const usage = total - cpu.times.idle;
      return (usage / total) * 100;
    });
    const avgCpuLoad = (cpuLoad.reduce((acc, load) => acc + load, 0) / cpus.length).toFixed(2);

    // Gửi thông tin trạng thái
    const statusMessage = `Dữ liệu thống kê:\nCpu: ${avgCpuLoad}%\nSử dụng RAM: ${usedMemInGB}GB/${totalMemInGB}GB (${memUsagePercent}%)`;
    bot.sendMessage(message.chat.id, statusMessage);
  },
};