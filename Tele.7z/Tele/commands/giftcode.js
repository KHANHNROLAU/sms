const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'giftcode',
  description: 'Sử dụng giftcode',
  execute(bot, message, args) {
    const accountsPath = path.join(__dirname, '../account.json');
    const giftcodesPath = path.join(__dirname, '../giftcode.json');
    const giftcodeInput = args && args.length > 0 ? args[0].toLowerCase() : null;

    if (!giftcodeInput) {
      return bot.sendMessage(message.chat.id, 'Vui lòng nhập giftcode.');
    }

    // Đọc file giftcode.json
    fs.readFile(giftcodesPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file giftcode.json.');
      }

      const giftcodes = JSON.parse(data || '{}');
      const giftcodeData = giftcodes[giftcodeInput];

      // Đọc file account.json
      fs.readFile(accountsPath, { encoding: 'utf8' }, (err, accountData) => {
        if (err) {
          console.error(err);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
        }

        const accounts = JSON.parse(accountData || '{}');
        const userId = message.from.id.toString();
        let account = accounts[userId];

        // Kiểm tra giftcode và giới hạn sử dụng
        if (giftcodeData && giftcodeData.uses > 0 && (!account || !account.usedGiftcodes || !account.usedGiftcodes[giftcodeInput])) {
          // Cập nhật số lượt sử dụng giftcode
          giftcodeData.uses -= 1;
          // Cập nhật số tiền trong tài khoản
          if (!account) {
            // Nếu không tồn tại, tạo tài khoản mới
            account = {
              ID: userId,
              Balance: 0,
              usedGiftcodes: {}
            };
          }
          if (!account.Balance) {
            account.Balance = 0;
          }
          account.Balance += giftcodeData.amount;

          // Đánh dấu giftcode đã được sử dụng
          if (!account.usedGiftcodes) {
            account.usedGiftcodes = {};
          }
          account.usedGiftcodes[giftcodeInput] = true;

          // Ghi lại thông tin vào file account.json
          fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
            if (writeErr) {
              console.error(writeErr);
              return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
            }
            // Format the success message with specified symbols
            const successMessage = [
              '┏━━━━━━━━━━━━━┓',
              `┣➤Giftcode '${giftcodeInput}' đã được sử dụng thành công.`,
              `┣➤Số tiền được cộng vào tài khoản: ${giftcodeData.amount.toLocaleString()} VND.`,
              `┣➤Số dư tài khoản của bạn là: ${account.Balance.toLocaleString()} VND.`,
              '┗━━━━━━━━━━━━━┛'
            ].join('\n');
            bot.sendMessage(message.chat.id, successMessage);
          });

          // Ghi lại thông tin vào file giftcode.json
          fs.writeFile(giftcodesPath, JSON.stringify(giftcodes, null, 2), (writeErr) => {
            if (writeErr) {
              console.error(writeErr);
              return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật file giftcode.json.');
            }
          });
        } else {
          return bot.sendMessage(message.chat.id, 'Giftcode không hợp lệ, đã hết lượt sử dụng, hoặc bạn đã sử dụng giftcode này.');
        }
      });
    });
  },
};
