const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'rmgiftcode',
  description: 'Xóa giftcode',
  execute(bot, message, args) {
    const adminId = '5990807551'; // Thay thế bằng ID Telegram của admin
    if (message.from.id.toString() !== adminId) {
      return bot.sendMessage(message.chat.id, 'Bạn không có quyền sử dụng lệnh này.');
    }

    const giftcodesPath = path.join(__dirname, '../giftcode.json');
    const giftcodeToRemove = args && args.length > 0 ? args[0].toLowerCase() : null;

    if (!giftcodeToRemove) {
      return bot.sendMessage(message.chat.id, 'Vui lòng nhập giftcode cần xóa.');
    }

    fs.readFile(giftcodesPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file giftcode.json.');
      }

      const giftcodes = JSON.parse(data || '{}');

      if (!giftcodes[giftcodeToRemove]) {
        return bot.sendMessage(message.chat.id, `Không tìm thấy giftcode: ${giftcodeToRemove}`);
      }

      delete giftcodes[giftcodeToRemove];

      fs.writeFile(giftcodesPath, JSON.stringify(giftcodes, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi xóa giftcode.');
        }
        bot.sendMessage(message.chat.id, `┏━━━━━━━━━━━━━┓\n┣➤Giftcode: '${giftcodeToRemove}'\n┣➤Status:Thành công\n┗━━━━━━━━━━━━━┛.`);
      });
    });
  },
};