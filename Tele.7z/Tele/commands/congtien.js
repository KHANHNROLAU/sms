const fs = require('fs');

module.exports = {
  name: 'congtien',
  description: 'Cộng tiền cho người dùng (chỉ dành cho admin)',
  execute(bot, message, args) {
    const adminId = '5990807551'; // Thay thế bằng ID Telegram của admin
    if (message.from.id.toString() !== adminId) {
      return bot.sendMessage(message.chat.id, 'Bạn không có quyền sử dụng lệnh này.');
    }

    const username = args.slice(0, -1).join(' '); // Lấy tên người dùng từ các đối số
    const amountToAdd = parseInt(args[args.length - 1], 10); // Lấy số tiền từ đối số cuối cùng

    if (!username || isNaN(amountToAdd)) {
      return bot.sendMessage(message.chat.id, 'Cú pháp không đúng. Vui lòng nhập /congtien [Tên Người Dùng] [Số Tiền].');
    }

    // Đọc file account.json
    fs.readFile('account.json', 'utf8', (err, data) => {
      if (err) {
        console.log('Error reading file:', err);
        return bot.sendMessage(message.chat.id, 'Lỗi khi đọc file dữ liệu.');
      }
      try {
        const accounts = JSON.parse(data);
        // Kiểm tra xem người dùng có tồn tại không
        const userAccount = accounts[username];
        if (userAccount) {
          // Cập nhật số dư cho người dùng
          userAccount.Balance += amountToAdd;
          // Ghi lại dữ liệu vào file
          fs.writeFile('account.json', JSON.stringify(accounts, null, 2), (writeErr) => {
            if (writeErr) {
              console.log('Error writing file:', writeErr);
              return bot.sendMessage(message.chat.id, 'Lỗi khi cập nhật dữ liệu.');
            }
            bot.sendMessage(message.chat.id, `┏━━━━━━━━━━━━━┓\n┣➤Value: ${amountToAdd.toLocaleString('vi-VN')} VND\n┣➤Người nhận: ${username}\n┣➤Status:Thành công\n┗━━━━━━━━━━━━━┛`);
          });
        } else {
          bot.sendMessage(message.chat.id, 'Không có tên người dùng này.');
        }
      } catch (parseErr) {
        console.log('Error parsing JSON:', parseErr);
        bot.sendMessage(message.chat.id, 'Lỗi khi phân tích cú pháp dữ liệu.');
      }
    });
  },
};