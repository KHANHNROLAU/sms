const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'topets',
  description: 'Hiển thị 4 người có thú cưng cấp cao nhất',
  execute(bot, message) {
    const accountsPath = path.join(__dirname, '../account.json');

    // Đọc file account.json
    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const petOwners = [];

      // Lọc người dùng có thú cưng và cấp thú cưng
      for (const [userId, acc] of Object.entries(accounts)) {
        if (acc.pet) {
          const petLevel = parseInt(acc.pet.split(' ')[1], 10);
          petOwners.push({ userId, petLevel, userName: acc.Name });
        }
      }

      // Sắp xếp theo cấp thú cưng giảm dần
      const topPetOwners = petOwners.sort((a, b) => b.petLevel - a.petLevel).slice(0, 4);

      // Hiển thị thông tin người dùng có thú cưng cấp cao nhất
      let messageText = '🐾 Top Pets 🐾\n\n';
      for (const { userName, petLevel } of topPetOwners) {
        messageText += `User Name: ${userName} - Pet Level: ${petLevel}\n`;
      }

      bot.sendMessage(message.chat.id, messageText);
    });
  },
};
