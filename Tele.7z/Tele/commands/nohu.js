const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'nohu',
  description: 'Đặt cược và có cơ hội nhân ba số tiền',
  execute(bot, message, args) {
  	if (args.length < 2) {
      return bot.sendMessage(message.chat.id, 'Lệnh không đúng, vui lòng /nohu [Số cược] [Số tiền cược]');
    }
    const chosenNumber = parseInt(args[0], 10);
    const betAmount = parseInt(args[1], 10);
    const userId = message.from.id.toString();
    const userName = message.from.username;
    const accountsPath = path.join(__dirname, '../account.json');

    // Đọc file account.json
    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const userAccount = accounts[userId];

      if (!userAccount) {
        return bot.sendMessage(message.chat.id, 'Tài khoản của bạn không tồn tại.');
      }

      if (isNaN(betAmount) || userAccount.Balance < betAmount) {
        return bot.sendMessage(message.chat.id, 'Số dư của bạn không đủ để đặt cược.');
      }

      if (isNaN(chosenNumber) || chosenNumber < 1 || chosenNumber > 20) {
        return bot.sendMessage(message.chat.id, 'Số bạn chọn phải nằm trong khoảng từ 1 đến 20.');
      }

      // Sinh số ngẫu nhiên từ 1 đến 20
      const randomNumber = Math.floor(Math.random() * 20) + 1;
      let resultMessage;

      if (chosenNumber === randomNumber) {
        // Nếu thắng
        userAccount.Balance += betAmount * 2; // Nhân số tiền nếu thắng
        resultMessage = `┏━━━━━━━━━━━━━┓\n┣➤Tên người đặt cược: ${userName}\n┣➤Số tiền đặt cược: ${betAmount}\n┣➤Số cược: ${chosenNumber}\n┣➤Số hệ thống đặt: ${randomNumber}\n┣➤Số tiền thắng: ${betAmount * 3}\n┣➤Thời gian đặt cược: ${new Date().toLocaleString('vi-VN')}\n┗━━━━━━━━━━━━━┛`;
      } else {
        // Nếu thua
        userAccount.Balance -= betAmount;
        resultMessage = `┏━━━━━━━━━━━━━┓\n┣➤Tên người đặt cược: ${userName}\n┣➤Số tiền đặt cược: ${betAmount}\n┣➤Số cược: ${chosenNumber}\n┣➤Số hệ thống đặt: ${randomNumber}\n┣➤Số tiền thua: ${betAmount}\n┣➤Thời gian đặt cược: ${new Date().toLocaleString('vi-VN')}\n┗━━━━━━━━━━━━━┛`;
      }

      // Ghi lại thông tin vào file account.json
      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
        }
        // Gửi thông báo kết quả
        bot.sendMessage(message.chat.id, resultMessage);
      });
    });
  },
};
