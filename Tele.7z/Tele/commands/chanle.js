const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'chanle',
  description: 'Đặt cược chẵn hoặc lẻ và xem kết quả xúc xắc',
  execute(bot, message, args) {
    // Kiểm tra xem người dùng đã nhập đủ thông tin không
    if (args.length < 2) {
      return bot.sendMessage(message.chat.id, 'Lệnh không đúng, vui lòng /chanle [chan/le] [Số tiền cược]');
    }

    const betOption = args[0].toLowerCase();
    const betAmount = parseInt(args[1], 10);
    const userId = message.from.id.toString();
    const userName = message.from.username;
    const accountsPath = path.join(__dirname, '../account.json');

    // Đọc file account.json
    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const userAccount = accounts[userId];

      if (!userAccount) {
        return bot.sendMessage(message.chat.id, 'Tài khoản của bạn không tồn tại.');
      }

      if (isNaN(betAmount) || userAccount.Balance < betAmount) {
        return bot.sendMessage(message.chat.id, 'Số dư của bạn không đủ để đặt cược.');
      }

      // Gửi xúc xắc và xử lý kết quả
      bot.sendDice(message.chat.id, {
        emoji: '🎲'
      }).then((diceResult) => {
        const diceValue = diceResult.dice.value;
        const isEven = diceValue % 2 === 0;
        let resultMessage;
        let winAmount;

        if ((betOption === 'chan' && isEven) || (betOption === 'le' && !isEven)) {
          // Nếu thắng
          winAmount = betAmount * 1.2;
          userAccount.Balance += winAmount;
          resultMessage = `┣➤Số tiền thắng: ${winAmount.toLocaleString()} VND`;
        } else {
          // Nếu thua
          userAccount.Balance -= betAmount;
          resultMessage = `┣➤Số tiền thua: ${betAmount.toLocaleString()} VND`;
        }

        // Cập nhật file account.json
        fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
          if (writeErr) {
            console.error(writeErr);
            return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
          }

          // Gửi thông báo kết quả
          const currentTime = new Date().toLocaleString('vi-VN');
          const formattedMessage = [
  '┏━━━━━━━━━━━━━┓',
  `┣➤Tên người đặt cược: ${userName}`,
  `┣➤Kết quả: ${isEven ? 'Chẵn' : 'Lẻ'}`,
  `┣➤Số tiền cược: ${betAmount.toLocaleString()} VND`,
  resultMessage,
  `┣➤Thời gian đặt cược: ${currentTime}`,
  '┗━━━━━━━━━━━━━┛'
          ].join('\n');
          bot.sendMessage(message.chat.id, formattedMessage);
        });
      }).catch(console.error);
    });
  },
};
