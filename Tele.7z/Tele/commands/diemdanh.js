const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'diemdanh',
  description: 'Điểm danh hàng ngày để nhận thưởng',
  execute(bot, message, args) {
    const accountsPath = path.join(__dirname, '../account.json');
    const userId = message.from.id.toString();

    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const userAccount = accounts[userId];
      const now = new Date();
      const today = now.toISOString().split('T')[0]; // Lấy ngày hiện tại

      if (!userAccount) {
        return bot.sendMessage(message.chat.id, 'Tài khoản của bạn không tồn tại.');
      }

      // Kiểm tra xem người dùng đã điểm danh hôm nay chưa
      if (userAccount.lastCheckIn === today) {
        return bot.sendMessage(message.chat.id, 'Bạn đã điểm danh rồi. Vui lòng quay lại vào ngày mai.');
      }

      // Cập nhật thời gian điểm danh cuối cùng và số dư
      userAccount.lastCheckIn = today;
      userAccount.Balance += 10000000000; // Thêm 10 tỷ vào tài khoản

      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
        }
        bot.sendMessage(message.chat.id, 'Bạn đã điểm danh thành công và nhận được 10 tỷ VND!');
      });
    });
  },
};
