const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'register',
  description: 'Đăng ký tài khoản mới',
  execute(bot, message, args) {
    const accountsPath = path.join(__dirname, '../account.json');
    const name = args && args.length > 0 ? args[0] : null;
    if (!name) {
      return bot.sendMessage(message.chat.id, 'Vui lòng cung cấp tên để đăng ký.');
    }

    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      let accounts;
      if (err) {
        if (err.code === 'ENOENT') {
          console.log('File account.json không tồn tại, sẽ tạo mới.');
          accounts = {};
        } else {
          console.error(err);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
        }
      } else {
        try {
          accounts = JSON.parse(data);
        } catch (parseErr) {
          console.error(parseErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi phân tích file account.json.');
        }
      }

      if (accounts[message.from.id]) {
        return bot.sendMessage(message.chat.id, 'Bạn đã đăng ký rồi.');
      }

      accounts[message.from.id] = {
        Name: name,
        ID: message.from.id,
        DateRegistered: new Date().toISOString(),
        Balance: 50000, // Thêm số tiền 50k vào tài khoản
        Gold: 0 // Số Vàng bắt đầu từ 0
      };

      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi lưu thông tin đăng ký.');
        }
        bot.sendMessage(message.chat.id, `Đăng ký thành công với tên: ${name}`);
      });
    });
  },
};
