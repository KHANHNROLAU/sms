const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'addgiftcode',
  description: 'Thêm giftcode mới',
  execute(bot, message, args) {
    const adminId = '5990807551'; // Thay thế bằng ID Telegram của admin
    if (message.from.id.toString() !== adminId) {
      return bot.sendMessage(message.chat.id, 'Bạn không có quyền sử dụng lệnh này.');
    }

    const giftcodesPath = path.join(__dirname, '../giftcode.json');
    const [giftcode, uses, amount] = args;

    if (!giftcode || !uses || !amount) {
      return bot.sendMessage(message.chat.id, 'Cú pháp không đúng. Vui lòng nhập /addgiftcode [giftcode] [số lượt dùng] [số tiền].');
    }

    fs.readFile(giftcodesPath, { encoding: 'utf8' }, (err, data) => {
      const giftcodes = JSON.parse(data || '{}');

      if (giftcodes[giftcode]) {
        return bot.sendMessage(message.chat.id, 'Giftcode này đã tồn tại.');
      }

      giftcodes[giftcode] = {
        giftcode,
        uses: parseInt(uses, 10),
        amount: parseInt(amount, 10)
      };

      fs.writeFile(giftcodesPath, JSON.stringify(giftcodes, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi thêm giftcode.');
        }
        bot.sendMessage(message.chat.id, `┏━━━━━━━━━━━━━┓\n┣➤Giftcode: '${giftcode}'\n┣➤Status: thành công\n┣➤ Value ${amount} VND\n┗━━━━━━━━━━━━━┛`);
      });
    });
  },
};