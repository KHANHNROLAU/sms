const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'nhantienpets',
  description: 'Nhận tiền cho thú cưng (2 ngày 1 lần)',
  execute(bot, message) {
    const accountsPath = path.join(__dirname, '../account.json');
    const userId = message.from.id.toString();
    const userAccount = message.from;

    // Đọc file account.json
    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');

      // Kiểm tra xem đã có thú cưng hay chưa
      if (!userAccount.pet) {
        return bot.sendMessage(message.chat.id, 'Bạn chưa có thú cưng.');
      }

      // Kiểm tra xem đã đủ thời gian để nhận tiền cho thú cưng chưa
      const lastCollected = new Date(userAccount.last_collected || '1970-01-01');
      const now = new Date();
      const timeSinceLastCollect = now - lastCollected;
      const twoDaysInMilliseconds = 2 * 24 * 60 * 60 * 1000; // 2 days in milliseconds

      if (timeSinceLastCollect < twoDaysInMilliseconds) {
        return bot.sendMessage(message.chat.id, '2 ngày thì mới nhận được 1 lần');
      }

      // Xác định số tiền nhận dựa trên cấp thú cưng
      const petLevel = parseInt(userAccount.pet.split(' ')[1], 10);
      const moneyReceived = [0, 10e9, 30e9, 40e9, 40e9, 60e9, 95e9, 135e9, 150e9, 185e9, 200e9][petLevel];

      // Cộng tiền vào tài khoản
      userAccount.Balance += moneyReceived;
      userAccount.last_collected = now.toISOString();

      // Ghi lại thông tin vào file account.json
      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
        }
        bot.sendMessage(message.chat.id, `Bạn đã nhận được ${moneyReceived.toLocaleString()} VND cho thú cưng cấp ${petLevel}.`);
      });
    });
  },
};
