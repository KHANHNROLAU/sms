const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'pets',
  description: 'Sử dụng lệnh /pets để nuôi thú cưng',
  execute(bot, message) {
    const accountsPath = path.join(__dirname, '../account.json');
    const userId = message.from.id.toString();

    // Đọc file account.json
    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const userAccount = accounts[userId];

      if (!userAccount) {
        return bot.sendMessage(message.chat.id, 'Tài khoản của bạn không tồn tại.');
      }

      // Kiểm tra xem đã có pets hay chưa
      if (userAccount.pet) {
        return bot.sendMessage(message.chat.id, 'Bạn đã có thú cưng rồi.');
      }

      // Trừ 10 tỷ tiền
      const cost = 10000000000;
      if (userAccount.Balance < cost) {
        return bot.sendMessage(message.chat.id, 'Số dư của bạn không đủ để nuôi thú cưng.');
      }
      userAccount.Balance -= cost;

      // Thêm thú cưng
      userAccount.pet = 'Cấp 1';

      // Ghi lại thông tin vào file account.json
      fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
        if (writeErr) {
          console.error(writeErr);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật thông tin tài khoản.');
        }
        bot.sendMessage(message.chat.id, 'Bạn đã nuôi thú cưng thành công! 🐾');
      });
    });
  },
};
