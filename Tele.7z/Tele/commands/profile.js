const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'profile',
  description: 'Xem thông tin hồ sơ',
  execute(bot, message) {
    const accountsPath = path.join(__dirname, '../account.json');

    fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
      }

      const accounts = JSON.parse(data || '{}');
      const account = accounts[message.from.id];

      if (account) {
        const profileInfo = [
          '┏━━━━━━━━━━━━━┓',
          `┣➤Tên: ${account.Name}`,
          `┣➤ID: ${account.ID}`,
          `┣➤Ngày tạo: ${account.DateRegistered}`,
          `┣➤Số tiền: ${account.Balance.toLocaleString()} VND`,
          `┣➤Vàng: ${account.Gold}`,
          '┗━━━━━━━━━━━━━┛'
        ].join('\n');
        bot.sendMessage(message.chat.id, profileInfo);
      } else {
        bot.sendMessage(message.chat.id, 'Không tìm thấy hồ sơ với ID này.');
      }
    });
  },
};
