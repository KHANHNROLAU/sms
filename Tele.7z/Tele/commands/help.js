const fs = require('fs');
const path = require('path');

module.exports = {
  name: 'help',
  description: 'Liệt kê tất cả các lệnh',
  execute(bot, message) {
    fs.readdir(path.join(__dirname), (err, files) => {
      if (err) {
        console.error(err);
        return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc các lệnh.');
      }
      const commandFiles = files.filter(file => file.endsWith('.js'));
      let commandList = '┏━━━━━━━━━━━━━┓\n';
      commandFiles.forEach(file => {
        const command = file.replace('.js', '');
        // Loại bỏ các lệnh quản trị khỏi danh sách
        if (!['rmgiftcode', 'addgiftcode', 'congtien', 'rmacc', 'editmoney'].includes(command)) {
          commandList += `┣➤/${command}\n`;
        }
      });
      commandList += '┗━━━━━━━━━━━━━┛';
      bot.sendMessage(message.chat.id, commandList);
    });
  },
};
