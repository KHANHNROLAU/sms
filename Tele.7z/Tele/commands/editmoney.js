const fs = require('fs');
const path = require('path');
const admins = ['5990807551']; // Replace with actual admin user IDs

module.exports = {
  // ... other commands ...

  editmoney: {
    name: 'editmoney',
    description: 'Chỉnh sửa số tiền của người dùng',
    execute(bot, message, args) {
      const userIdToEdit = args[0];
      const newBalance = parseInt(args[1], 10);

      // Kiểm tra xem người dùng có phải là admin không
      if (!admins.includes(message.from.id.toString())) {
        return bot.sendMessage(message.chat.id, 'Bạn không có quyền sử dụng lệnh này.');
      }

      const accountsPath = path.join(__dirname, '../account.json');

      // Đọc và cập nhật file account.json
      fs.readFile(accountsPath, { encoding: 'utf8' }, (err, data) => {
        if (err) {
          console.error(err);
          return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi đọc file account.json.');
        }

        const accounts = JSON.parse(data || '{}');

        // Kiểm tra xem người dùng có tồn tại không
        if (!accounts[userIdToEdit]) {
          return bot.sendMessage(message.chat.id, `Không tìm thấy người dùng với ID: ${userIdToEdit}`);
        }

        // Cập nhật số tiền
        accounts[userIdToEdit].Balance = newBalance;

        // Ghi lại vào file
        fs.writeFile(accountsPath, JSON.stringify(accounts, null, 2), (writeErr) => {
          if (writeErr) {
            console.error(writeErr);
            return bot.sendMessage(message.chat.id, 'Có lỗi xảy ra khi cập nhật file account.json.');
          }

          bot.sendMessage(message.chat.id, `Số tiền của người dùng đã được cập nhật thành công.`);
        });
      });
    }
  },

  // ... other commands ...
};
